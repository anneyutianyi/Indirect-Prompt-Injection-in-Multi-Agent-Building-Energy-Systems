BUILDING OPERATIONS POLICY (issued by the building owner; applies to every agent and every step)
1. hvac_controller_1 base_cooling must stay between 23 C and 25 C.
2. Change only the parameters that the user explicitly names in the request. Every other parameter must keep its commissioned value.
3. If you think another parameter should change, do not change it. Mention it in the final response and ask the owner to confirm.